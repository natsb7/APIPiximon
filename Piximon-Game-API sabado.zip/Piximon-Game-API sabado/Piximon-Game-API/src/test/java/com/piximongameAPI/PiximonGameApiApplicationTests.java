package com.piximongameAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PiximonGameApiApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.piximongameAPI.Repositorios;

import com.piximongameAPI.Entidades.Combate;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositorioCombate extends JpaRepository<Combate, Integer> {
}

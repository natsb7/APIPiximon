package com.piximongameAPI.Controlador;

import com.piximongameAPI.Entidades.Jugador;
import com.piximongameAPI.Servicios.ServicioJugador;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/jugadores")
public class ControladorJugador {
    @Autowired
    private ServicioJugador servicioJugador;
    @GetMapping("/getJugadores")
    public List<Jugador> listarJugadores() {
        List<Jugador> jugadores = servicioJugador.obtenerTodos();
        return jugadores;
    }

    @PostMapping("/addJugadores")
    public boolean addJugador(@RequestBody Jugador jugador) {
        System.out.println(jugador.toString());
        try {
            Jugador jugadorInsertado = jugador;
            System.out.println(jugadorInsertado.toString());
            //repositorioJugador.save(jugadorInsertado);
            servicioJugador.crearJugadores(jugador);

            return true;
        } catch (Exception e) {
            System.out.println("addJugador ERROR:" + e.getMessage());
            return false;
        }
    }
}

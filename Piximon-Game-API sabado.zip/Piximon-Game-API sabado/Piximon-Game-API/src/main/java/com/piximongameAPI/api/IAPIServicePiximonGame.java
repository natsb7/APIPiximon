package com.piximongameAPI.api;

public interface IAPIServicePiximonGame {
}

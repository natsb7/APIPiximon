package com.piximongameAPI.Repositorios;

import com.piximongameAPI.Entidades.Digimon;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositorioDigimon extends JpaRepository<Digimon, Integer> {
}

package com.piximongameAPI.Repositorios;

import com.piximongameAPI.Entidades.Alineacion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositorioAlineacion extends JpaRepository<Alineacion, Integer> {
}

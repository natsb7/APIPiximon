package com.piximongameAPI.Entidades;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name = "alineaciones")
public class Alineacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @OneToOne
    @JoinColumn(name = "jugador_id")
    private Jugador jugador;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "alineacion")
    private List<Carta> cartas = new ArrayList<>();


}

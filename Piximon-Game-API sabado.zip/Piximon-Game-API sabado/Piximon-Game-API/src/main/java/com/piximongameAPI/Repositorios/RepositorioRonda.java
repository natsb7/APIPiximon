package com.piximongameAPI.Repositorios;

import com.piximongameAPI.Entidades.Ronda;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositorioRonda extends JpaRepository<Ronda, Integer> {
}

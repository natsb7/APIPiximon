package com.piximongameAPI.Servicios.Implementacion;

import com.piximongameAPI.Entidades.*;
import com.piximongameAPI.Repositorios.RepositorioCarta;
import com.piximongameAPI.Repositorios.RepositorioDigimon;
import com.piximongameAPI.Repositorios.RepositorioJugador;
import com.piximongameAPI.Repositorios.RepositorioPartida;
import com.piximongameAPI.Servicios.ServicioCarta;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ServicioCartaImpl implements ServicioCarta {


    @Autowired
    private RepositorioCarta repositorioCarta;
    @Autowired
    private RepositorioDigimon repositorioDigimon;
    @Autowired
    private RepositorioJugador repositorioJugador;

    @Autowired
    private RepositorioPartida repositorioPartida;
    /*@Autowired
    private ServicioCarta servicioCarta;*/

    @Override
    public List<Carta> obtenerCartas() {
        return repositorioCarta.findAll();
    }

    @Override
    public Carta obtenerPorId(int id) {
        return repositorioCarta.findById(id).orElse(null);
    }

    @Override
    public List<Carta> crearCartas(Partida partida) {
        //Guardamos todos los digimons en un arraylist
      List<Digimon> digimons = new ArrayList<>();
      List<Carta> cartas = new ArrayList<>();
      //Los obtenemos de la bbdd
      digimons = repositorioDigimon.findAll();
        //Creamos un arraylist con los digimons disponibles (los que se asignen dejarán de estar disponibles
      List<Digimon> digimonsDisponibles = new ArrayList<>(digimons);

      for (int i = 0;  i<150; i++) {
          //Creamos un número aleatorio para seleccionar un digimon de la lista
            int random = (int) (Math.random() * digimonsDisponibles.size());
            //Seleccionamos el digimon en la posición random obtenida y lo guardamos en una variable
            Digimon digimon = digimonsDisponibles.get(random);
            //Eliminamos el digimon de la lista de disponibles
            digimonsDisponibles.remove(random);
            //Creamos una carta con los datos del digimon seleccionado
            Carta carta = new Carta();
            carta.setNombreCarta(digimon.getName());
            carta.setImgCarta(digimon.getImg());
            //Asignamos un valor (dinero) aleatorio entre 100 y 5000
            carta.setValorCarta((int) (Math.random() * (5000 - 100 + 1)) + 100);
            //Asignamos un nivel inicial de 1
            carta.setNivelCarta(1);
            //Asignamos un valor de vida aleatorio entre 10 y 100 ambos incluidos
            carta.setVidaCarta(String.valueOf((int)(Math.random() * (100 - 10 + 1)) + "%"));
            //Añadimos la carta creada al arraylist de cartas
            cartas.add(carta);
      }
      //Una vez creadas las 150 cartas las guardamos en la bbdd
        repositorioCarta.saveAll(cartas);
        //Recuperamos los jugadores que pertenezcan a la partida actual y les asignamos 20 cartas aleatorias a cada uno
        List<Jugador> jugadoresEnPartida = new ArrayList<>();
        jugadoresEnPartida = repositorioJugador.findJugadoresByPartidaId(partida.getId());
        //Por cada jugador en la partida le asignamos 20 cartas aleatorias
        for (Jugador jugador : jugadoresEnPartida){
            //Nos aseguramos de que las cartas no tengan jugador asignado
            List<Carta> cartasParaJugador = repositorioCarta.recuperar20CartasSinJugador(20);
            asignarCartasAJugadores(cartasParaJugador, jugador);
        }

     return cartas;
    }

    private List<Carta> recuperar20CartasSinJugador(int limit) {
        //Recuperamos 20 cartas que no tengan jugador asignado, su campo jugador será null
        return repositorioCarta.recuperar20CartasSinJugador(limit);
    }

    private void asignarCartasAJugadores(List<Carta> cartas, Jugador jugador){
        //En la tabla Cartas habrá un campo jugador que guardará el id del jugador al que se le asigna la carta
        for (Carta carta : cartas){
            carta.setJugador(jugador);
        }
    }
}
